﻿/*Načti celé číslo n a celé číslo k. Potom načti pole n celých čísel. Vypiš každé 
číslo, jehož index není dělitelný číslem k. Nakonec vypiš rozdíl součtu všech 
vypsaných čísel a všech ostatních čísel z pole. */
int n, k, soucetOstatnich, rozdil;
int soucetVsech = 0, soucetDelitelnych = 0;
Console.WriteLine("Zadej celé číslo n:");
n = int.Parse(Console.ReadLine());
Console.WriteLine("Zadej celé číslo k:");
k = int.Parse(Console.ReadLine());
int[] pole = new int[n];
for (int i = 0; i < n; i++)
{
    Console.WriteLine("Zadej {0}. číslo:", i + 1);
    pole[i] = int.Parse(Console.ReadLine());
    soucetVsech+=pole[i];
    
}
Console.WriteLine("Čísla, jejichž index není dělitelný číslem {0} jsou: ", k);
for (int i = 0; i < n; i++)
{
    if (i % k != 0)
    {
        soucetDelitelnych += pole[i];
        Console.WriteLine("{0}, ", pole[i]);
    }
    
}
Console.WriteLine(" ");
soucetOstatnich = soucetVsech - soucetDelitelnych;
rozdil= soucetDelitelnych - soucetOstatnich;
Console.WriteLine("Rozdíl součtu všech vypsaných čísel a všech ostatních čísel je: {0}", rozdil);