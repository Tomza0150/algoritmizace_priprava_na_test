﻿//priklad 1
/*Načti celé číslo n. Dokud není číslo n z intervalu ⟨3,40⟩, načítej číslo n znovu. 
Potom načti pole n reálných čísel. Program vypíše všechny prvky, které nejsou celá 
čísla. Nakonec program vypíše, které číslo je nejmenší a počet kladných čísel. */
using System.Security.Authentication.ExtendedProtection;

int n, k = 0;
bool jeKladne = false;
bool jeNejmensi = false;
bool jeMensi= false;
bool vsechnaCislaJsouCela = true;
do
{
    Console.WriteLine("Zadejte celé číslo v intervalu <3;40>:");
    n = int.Parse(Console.ReadLine());
}
while (n < 3 || n > 40);
double[] pole = new double[n];
for (int i = 0; i < n; i++)
{
    Console.WriteLine("Zadejte {0}. reálné číslo:",i+1);
    pole[i] = double.Parse(Console.ReadLine());
   
}
Console.WriteLine("Prvky, které nejsou celými čísly jsou:");
for (int i = 0; i < n; i++)
{
    if (pole[i] % 1 != 0)
    {
        
        Console.Write(" {0};", pole[i]);
        vsechnaCislaJsouCela = false;
    }
    
}
if (vsechnaCislaJsouCela == true)
{
    Console.WriteLine("Všechna čísla jsou celá.");
}
Console.WriteLine(" ");
for (int i = 0; i < n; i++)
{
   if (pole[i] > 0)
    {
        k++;
        jeKladne = true;
    }

}
if (jeKladne == true)
{
    Console.WriteLine("Počet kladných čísel je: {0}", k);
}
else if (jeKladne == false)
{
    Console.WriteLine("Neexistují žádná kladná čísla.");
}
    double nejmensi = pole[0];
for (int i = 0; i < n; i++)
{
    if (pole[i]< nejmensi)
    {
        nejmensi = pole[i];
    }
}
Console.WriteLine("Nejmenší číslo je {0}.", nejmensi);
/*for (int i = 0; i < n; i++)
{
    if (pole[i] < pole[i+1])
    {
        jeNejmensi = true;
    }
    if (jeNejmensi == true)
    {
        Console.WriteLine("Nejmenší číslo je: {0}", pole[i]);
    }
}*/
