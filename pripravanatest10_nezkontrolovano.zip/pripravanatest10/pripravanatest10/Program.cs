﻿/*  Načti celé kladné číslo n. Načti n reálných čísel a jejich desetinné části ulož do 
pole. Zjisti a vypiš, zda desetinné části zadaných čísel tvoří rostoucí, nerostoucí, 
klesající, neklesající, nebo ani jednu ze zmíněných posloupností. 
 */
int n;
bool rostouci = false, klesajici = false, stejne = false;
do
{
    Console.WriteLine("Zadejte celé kladné číslo:");
    n = int.Parse(Console.ReadLine());
}
while (n <= 0);
double[] desetinnacast = new double[n];
double[] pole=new double[n];
for (int i = 0; i < n; i++)
{
    Console.WriteLine("Zadejte {0}. reálné číslo: ", i+1);
    pole[i]=double.Parse(Console.ReadLine());
    desetinnacast[i] = pole[i] - (int)pole[i];
}
for  (int i = 0;i < n-1; i++)
{
    
    if (desetinnacast[i] > desetinnacast[i+1])
    {
        klesajici = true;
    }
    else if (desetinnacast[i] < desetinnacast[i+1])
    {
        rostouci = true;
    }
    else if (desetinnacast[i] == desetinnacast[i+1])
    {
        stejne = true;
    }
}
if (rostouci&& !klesajici&&!stejne)
{
    Console.WriteLine("Posloupnost desetinných částí reálných čísel je rostoucí.");
}
else if (klesajici&& !rostouci&&!stejne)
{
    Console.WriteLine("Posloupnost desetinných částí reálných čísel je klesající.");
}
else if (klesajici&&stejne&&!rostouci)
{
    Console.WriteLine("Posloupnost desetinných částí reálných čísel je nerostoucí.");
}
else if (rostouci&&stejne&&!klesajici)
{
    Console.WriteLine("Posloupnost desetinných částí reálných čísel je neklesající.");
}
else if (!klesajici && !rostouci && !stejne)
{
    Console.WriteLine("Posloupnost desetinných částí reálných čísel není ani rostoucí, ani klesající.");
}
else
{
    Console.WriteLine("Někde se stala chyba.");
}
