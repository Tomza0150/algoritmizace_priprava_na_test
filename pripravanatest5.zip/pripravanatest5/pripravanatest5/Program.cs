﻿/*Načítej celé číslo n, dokud není z intervalu ⟨10,60). Načítej celé číslo m, dokud 
není větší než n a menší než 90. Pro hodnoty od n do m vypiš tabulku. První sloupec 
bude aktuální hodnota. Druhý sloupec bude obvod kruhu, jehož poloměr je roven 
aktuální hodnotě. Třetí sloupec bude obsah takového kruhu. Reálné hodnoty 
vypisujte s přesností na 2 desetinná čísla.
 */

int n, m;
double obvod, obsah;
string h="hodnota", o="obvod", s="obsah";
do
{
    Console.WriteLine("Zadejte číslo n v intervalu <10;60):");
    n = int.Parse(Console.ReadLine());
    

}
while (n<10||n>=60);
do
{
    Console.WriteLine("Zadejte číslo m v intervalu (n;90): ");
    m = int.Parse(Console.ReadLine());
}
while (m<=n || m>=90);
Console.WriteLine("{0,-10} {1,-10} {2,-10}", h,o,s);
for (int i = n; i<=m ; i++)
{
    obvod=2*Math.PI*i;
    obsah=Math.PI*Math.Pow(i,2);
    Console.WriteLine("{0,-10:F2} {1,-10:F2} {2,-10:F2}", i, obvod, obsah);
    

}