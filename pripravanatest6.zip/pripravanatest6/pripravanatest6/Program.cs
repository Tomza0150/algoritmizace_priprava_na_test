﻿/* Načítej celé číslo n, dokud není n kladné číslo menší než 30. Načti n řetězců, 
které mají představovat nějaký recyklovatelný odpad. Program vypíše tabulku, ve 
které bude pro každý rozeznávaný typ odpadu vypsána informace o počtu 
načtených kusů odpadu daného typu. Dále program vypíše pro každý nejčastější 
typy odpadu (počet výskytů daného typu je roven největšímu počtu výskytů typu) a 
do jaké popelnice daný typ patří. Rozeznávané odpady jsou vypsány v následující 
tabulce. */
int n;
int pet = 0;
int igelitka = 0;
int karton = 0;
int noviny = 0;
int sklenice = 0;
int plechovka = 0;
int konzerva = 0;
int plast = 0;
int papir= 0;
int sklo = 0;
int kov = 0;
string pa ="papír";
string pl = "plast";
string sk = "sklo";
string ko = "kov";

do
{    
    Console.Write("Zadej počet odpadů (1-29): ");
    n = int.Parse(Console.ReadLine());
} 
while (n <= 0 || n >= 30);
string[] odpad = new string[n];
Console.WriteLine("Možnosti odpadků: pet lahev, igelitka, karton, noviny, sklenice, plechovka, konzerva ");
for (int  i = 0;  i < n;  i++)
{
    Console.WriteLine("Zadejte {0}. odpadek:", i + 1);
    odpad[i] = Console.ReadLine();
    if(odpad[i] == "pet lahev")
    {
        pet++;
    }
    else if(odpad[i] == "igelitka")
    {
        igelitka++;
    }
    else if(odpad[i] == "karton")
    {
        karton++;
    }
    else if(odpad[i] == "noviny")
    {
        noviny++;
    }
    else if(odpad[i] == "sklenice")
    {
        sklenice++;
    }
    else if(odpad[i] == "plechovka")
    {
        plechovka++;
    }
    else if(odpad[i] == "konzerva")
    {
        konzerva++;
    }
    else
    {
        Console.WriteLine("Neznámý odpadek, zadejte znovu.");
        i--; // Snížení indexu pro opětovné zadání odpadku
    }
}

plast = pet + igelitka;
papir = karton + noviny;
sklo = sklenice;
kov = plechovka + konzerva;
Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10}", pl, pa, sk, ko);
Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10}", plast, papir, sklo, kov);

string nejcastejsiTyp;
string popelnice;
string zl="žlutá";
string mo="modrá";
string ze="zelená/bílá";
string se="šedá/žlutá s šedou nálepkou";
/*// natvrdo přes if
if (plast>papir && plast>sklo&&plast>kov)
{ 
    nejcastejsiTyp = pl;
}
else if (papir>plast && papir>sklo&&papir>kov)
{
    nejcastejsiTyp = pa;
}
else if (sklo>plast && sklo>papir&&sklo>kov)
{
    nejcastejsiTyp = sk;
}
else if (kov>plast && kov>papir&&kov>sklo)
{
    nejcastejsiTyp = ko;
}
else
{
    nejcastejsiTyp = "Nejčastější typ odpadu není jednoznačný.";
}

if (nejcastejsiTyp==pl)
{
    Console.WriteLine("Nejčastější typ odpadu je {0} a patří do popelnice, která je {1}", pl,zl);
}
else if (nejcastejsiTyp==pa)
{
    Console.WriteLine("Nejčastější typ odpadu je {0} a patří do popelnice, která je {1}", pa,mo);
}
else if (nejcastejsiTyp==sk)
{
    Console.WriteLine("Nejčastější typ odpadu je {0} a patří do popelnice, která je {1}", sk,ze);
}
else if (nejcastejsiTyp==ko)
{
    Console.WriteLine("Nejčastější typ odpadu je {0} a patří do popelnice, která je {1}", ko,se);
}
else
{
    Console.WriteLine("Nelze určit nejčastější typ a tím pádem ani popelnici");
}*/
//přes math.max

int maxvyskyt;
maxvyskyt=Math.Max(Math.Max(plast,papir),Math.Max(sklo,kov));
if (plast == maxvyskyt)
{
    Console.WriteLine("Nejčastější typ odpadu je {0} a patří do popelnice, která je {1}", pl,zl);
}
if (papir == maxvyskyt)
{
    Console.WriteLine("Nejčastější typ odpadu je {0} a patří do popelnice, která je {1}", pa,mo);
}
if (sklo == maxvyskyt)
{
    Console.WriteLine("Nejčastější typ odpadu je {0} a patří do popelnice, která je {1}", sk,ze);
}
if (kov == maxvyskyt)
{
    Console.WriteLine("Nejčastější typ odpadu je {0} a patří do popelnice, která je {1}", ko,se);
}
Console.ReadKey();

