﻿/*Načítej celé číslo n a celé číslo k,  dokud neplatí, že n je větší než k. Program 
vypíše k-tou cifru zleva čísla n.*/
int n, k, c, d, pomoc;
// d celkový počet cifer čísla n, c k-tá cifra zleva čísla n
do
{
    Console.WriteLine("Zadejte číslo n:");
    n = int.Parse(Console.ReadLine());
    Console.WriteLine("Zadejte číslo k:");
    k = int.Parse(Console.ReadLine());
}
while (n<=k);
d=(int)Math.Log10(n)+1;
pomoc=(int)Math.Pow(10, d-k);
c=(n/pomoc)%10;

Console.WriteLine("{0}. cifra zleva čísla {1} je {2}.", k, n, c);