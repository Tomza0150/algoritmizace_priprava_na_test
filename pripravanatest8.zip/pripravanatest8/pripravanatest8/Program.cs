﻿/*Načti dvě celá čísla a, b. Najdi a vypíš všechna prvočísla v rozmezí od a do b 
včetně.*/
using System.Security.Authentication.ExtendedProtection;

int a, b, x;
do
{
    Console.WriteLine("Zadejte číslo a:");
    a = int.Parse(Console.ReadLine());
    Console.WriteLine("Zadejte číslo b:");
    b = int.Parse(Console.ReadLine());
}
while (a > b);

int[] pole= new int[b-a+1];

for (x=a;x<=b;x++)
{
    if (x<=1)
    {
        continue;
    }
    bool jePrvocislo = true;
    for (int i = 2; i <= x; i++) 
    {
        if (x%i==0 && i!=x)
        { jePrvocislo = false;
            break;
        }
    }
    if (jePrvocislo)
    {
        Console.WriteLine("{0}, ",x);
    }
}
Console.ReadKey();

