﻿/*Načítej celé číslo n, dokud není z intervalu ⟨5,50⟩. Potom načti pole n celých 
čísel. Program vypíše všechna sudá čísla. Nakonec program vypíše součet všech 
sudých čísel a kolik z n čísel bylo sudých. */
int n;
int soucet = 0, pocetSudych = 0;
bool jeSude = false;
do
{
    Console.WriteLine("Zadejte číslo v intervalu <5;50>:");
    n = int.Parse(Console.ReadLine());
}
while (n < 5 || n > 50);
int[] pole = new int[n];
for (int i=0;i<n;i++)
{
    Console.WriteLine("Zadejte {0}. prvek:", i+1);
    pole[i] = int.Parse(Console.ReadLine());
}

Console.WriteLine("Sudá čísla jsou: ");
for (int i=0;i<n;i++)
{
    if (pole[i]%2==0)
    {
        jeSude = true;
        pocetSudych++;
        soucet+=pole[i];
        Console.Write("{0}, ", pole[i]);

    }
   
}
if (!jeSude)
{
    Console.WriteLine("Žádné číslo není sudé.");
}

Console.WriteLine("Sudých čísel je {0} a jejich součet je {1}.", pocetSudych, soucet);