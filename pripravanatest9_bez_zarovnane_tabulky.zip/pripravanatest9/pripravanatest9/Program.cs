﻿/*Načti celé kladné číslo n. Načti pole n reálných čísel. Vypiš tabulku, kde v prvním 
sloupci bude hodnota prvku pole, v druhém jeho druhá odmocnina, ve třetím jeho 
druhá mocnina a ve čtvrtém jeho desetinná část. Nezapomeň na zarovnání tabulky 
a hlavičku. */
int n;
double odmocnina, mocnina, desetinnacast, hodnota;
string h="hodnota", o = "druhá odmocnina", m="druhá mocnina", d="desetinná část";

do
{
    Console.WriteLine("Zadej kladné číslo n:");
    n = int.Parse(Console.ReadLine());
    
}
while (n <= 0);
double[] pole = new double[n];
for (int i = 0; i < n; i++)
{
    Console.WriteLine($"Zadej {i + 1}. prvek pole:");
    pole[i] = double.Parse(Console.ReadLine());
}
Console.WriteLine("{0,10} {1,10} {2,10} {3,10}", h, o, m, d);
for (int i=0;i<n;i++)
{
    //hodnota
    hodnota=pole[i];
    //odmicnina
    odmocnina = Math.Sqrt(pole[i]);
    //mocnina
    mocnina = Math.Pow(pole[i], 2);
    //desetinnacast
    //desetinnacast = pole[i] - Math.Floor(pole[i]);
    //desetinnacast = pole[i] % 1;
    //desetinnacast = pole[i] - (int)pole[i];
    //komentáře poradil github copilot, neručím za správnost

    desetinnacast = pole[i] - (int)pole[i];
    Console.WriteLine("{0,10}{1,10:F2}{2,10:F2}{3,10:F2}", hodnota, odmocnina, mocnina, desetinnacast);
}
Console.ReadKey();