﻿/*Načti celé číslo n, které reprezentuje počet jízd hromadnou městskou dopravou. 
Zjisti, zda má uživatel nárok na slevu. Načti pro každou jízdu délku jízdy v minutách. 
Vypočítej celkovou cenu za všechny jízdy podle následující tabulky. Vypiš celkovou 
cenu se zaokrouhlením na dvě desetinná místa a pokud měl uživatel nárok na slevu, 
tak napiš, kolik díky ní ušetřil. Nezapomeň kontrolovat, že zadané hodnoty dávají 
smysl (například, že není zadán záporný počet jízd).*/
int n, doba;
double cena, rozdil, cenabezslevy;
string sleva;
bool maSlevu=false;
int do15 = 0;// 18
int do60 = 0; //25
int do120 = 0; // 40
int nad120 = 0; // 55

do
{
    Console.WriteLine("Zadejte počet jízd: ");
    n = int.Parse(Console.ReadLine());
}
while (n<=0);
int[] jizdy = new int[n];
Console.WriteLine("Pokud máte nárok na slevu, zadejte ANO, pokud nemáte, zadejte NE:");
do
{
    
    sleva = Console.ReadLine();
    if (sleva == "ANO")
    {
        maSlevu = true;
    }
    else if (sleva == "NE")
    {
        maSlevu = false;
    }
    else
    {
        Console.WriteLine("Neplatný vstup, opakujte ještě jednou.");
        Console.WriteLine("Zadejte znovu ANO nebo NE: ");
    }
}
while (sleva != "ANO" && sleva != "NE");
    for (int i = 0; i < n; i++)
    {
    Console.WriteLine("Zadejte délku {0}. jízdy: ", i + 1);
    doba = int.Parse(Console.ReadLine());

        if (doba >= 0 && doba <= 15)
        {
            do15++;
        }
        else if (doba > 15 && doba <= 60)
        {
            do60++;
        }
        else if (doba >= 61 && doba <= 120)
        {
            do120++;
        }
        else if (doba > 120)
        {
            nad120++;
        }


    }
if (!maSlevu)
{
    cena = do15 * 18 + do60 * 25 + do120 * 40 + nad120 * 55;
    Console.WriteLine("Za jízdné zaplatíte {0:F2} Kč.", cena);
}
else if(maSlevu)
{
    cena = do15 * 15 + do60 * 20 + do120 * 35 + nad120 * 50;
    cenabezslevy = do15 * 18 + do60 * 25 + do120 * 40 + nad120 * 55;
    rozdil = cenabezslevy - cena;
    Console.WriteLine("Za jízdné zaplatíte {0:F2} Kč. Díky slevě ušetříte {1:F2} Kč.", cena, rozdil);
}
else
{
    Console.WriteLine("Někde se stala chyba.");
}